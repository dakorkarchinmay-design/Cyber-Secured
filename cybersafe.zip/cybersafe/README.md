# CyberSafe: Smart Digital Safety Assistant for Students

A working, mobile-friendly prototype that teaches students (and teachers and first-time internet users) to recognise online threats and protect themselves. Built with plain **HTML, CSS and JavaScript**: no frameworks, no build step, no server, no accounts.

---

## 1. Run it locally

**Easiest (no installs):** unzip the folder and double-click `index.html`. It opens in any modern browser (Chrome, Edge, Firefox, Safari).

**Optional local server** (if your browser blocks something on `file://`):

```bash
cd cybersafe
python3 -m http.server 8000      # then open http://localhost:8000
# or: npx serve .
```

**On your phone:** run the server above, make sure your phone is on the same Wi-Fi, and open `http://<your-computer-ip>:8000`. The layout switches to a bottom tab bar on small screens.

Nothing needs installing, and nothing is sent over the internet.

---

## 2. What is inside

```
cybersafe/
├── index.html   page shell + navigation
├── styles.css   mobile-first, accessible, light/dark styling
├── data.js      ALL sample content (lessons, scenarios, quiz, plan, emergency guides)
├── app.js       logic: routing, lab, password coach, quiz, plan, dashboard
└── README.md
```

To add content, edit only `data.js`. For example, add a quiz question to `questions`, a scenario to `scenarios`, or a lesson to `modules`.

### Feature map

| # | Required feature | Where to find it |
|---|---|---|
| 1 | Phishing detection | **Practice → Phishing Lab**: 9 fictional emails, chats and fake/real websites. Tap the link to preview its real destination, then decide *Suspicious* or *Looks safe*. Instant red-flag explanation. |
| 2 | Password safety checker | **Practice → Password Coach**: checks a *practice* password locally (length, common words, leetspeak, sequences, years) plus a secure random password/passphrase generator. Nothing is stored or sent. |
| 3 | Scam awareness | **Learn → Scam Radar**: fake jobs, UPI fraud, OTP scams, social engineering, remote-access and blackmail. |
| 4 | Privacy protection | **Learn → Privacy Shield**: social media settings, app permissions, public Wi-Fi, digital footprint. |
| 5 | Cybersecurity quiz | **Quiz**: 20 questions in 4 topics, 5 or 10 per round, instant feedback, "what you got wrong and why", retry-missed mode. |
| 6 | Safety action plan | **Practice → Safety Plan**: pick your concerns, get a prioritised Today / This week / This month checklist with progress. |
| 7 | Emergency guidance | **Emergency**: step-by-step guides for a hacked account, a clicked link, lost money / shared OTP, blackmail, and a lost device. |
| – | Student progress dashboard | **Home**: module completion, phishing accuracy, quiz trend and improvement, badges, feedback, export. |

### Try this 3-minute demo
1. **Learn → Spot Phishing →** *Mark module complete*.
2. **Quiz →** take 5 questions (this is your baseline).
3. **Practice → Phishing Lab →** play all 9 scenarios.
4. **Practice → Password Coach →** type `P@ssw0rd1`, then try the passphrase generator.
5. **Practice → Safety Plan →** tick "I use UPI" and build the plan.
6. Take the quiz again, then open **Home** to see improvement and badges.

---

## 3. Privacy and safety by design

- **No real secrets collected.** The Password Coach tells users to type made-up passwords only. The text is evaluated in memory and never stored, logged or transmitted. Only a "tool was used" flag is saved.
- **No network calls at all**: no analytics, no external fonts, no CDN scripts.
- **Only learning progress is saved**, in the browser's `localStorage` (module ticks, quiz scores, lab accuracy, plan ticks, optional feedback). Users can export it or reset it from the Home screen.
- **All examples are fictional**: brands (Unity Bank, ShopKart), people and numbers are invented, and domains use the reserved `.example` ending, which cannot exist on the real internet.
- The only real-world contacts shown are India's national cybercrime resources (helpline **1930** and **cybercrime.gov.in**), with a note to verify on official sites.
- The password generator uses the browser's cryptographically secure random source (`crypto.getRandomValues`).
- All user-typed text shown back on screen is HTML-escaped.

**Accessibility:** semantic HTML, skip link, keyboard-friendly controls, 44px touch targets, visible focus, status text alongside colour (✓ / ✗), `aria-live` feedback, dark mode, and reduced-motion support.

---

## 4. How the success metrics are measured

| Metric | How the prototype captures it |
|---|---|
| Quiz improvement | Every quiz saves a score. The dashboard compares the **first (baseline) quiz to the latest** and draws a trend line. |
| Phishing recognition accuracy | The lab counts correct vs. total answers and shows the percentage. |
| Module completion rate | Modules completed out of 4, shown as a percentage. |
| Student feedback | A 1–5 rating and short comment on the Home screen. |

Students can **download their progress as JSON** (Home → *Download my progress*). In a classroom pilot, teachers can collect these files and compare pre/post results. A real deployment would add a privacy-safe backend (see Future scope).

---

## 5. Innovation

- **Learn-by-doing, not reading.** Students judge realistic fake messages and websites and get an immediate, specific explanation of *why*, which builds the habit of pausing and checking.
- **Includes safe examples on purpose.** 3 of the 9 lab scenarios are legitimate. Teaching only "everything is a scam" creates fear and distrust; students learn to tell real from fake.
- **Local-first, privacy-first.** A password coach that never sees a real password and has no server is itself a lesson in responsible technology.
- **Context for India.** UPI collect-request fraud, OTP/KYC calls, fake internship fees and fake scholarships are the scams students actually meet.
- **Personalised Safety Plan.** Concerns map to a prioritised action list, so students leave with concrete next steps instead of general advice.
- **Emergency mode.** Calm, ordered, tickable steps for the moment people actually panic.
- **Tiny and hackable.** Four files, no dependencies, so a student team can understand and extend all of it.

## 6. Social impact

- Online fraud hits students and first-time internet users hardest: new bank accounts, UPI, job hunting and unfamiliar platforms.
- It is free, works offline after the first load, runs on low-end phones, and needs no sign-up, so it can reach colleges, clubs, libraries and community centres.
- Short, plain-language lessons suit non-technical users and teachers who want classroom-ready material.
- Emphasises reporting quickly and *not blaming victims*, which reduces the shame that stops people from seeking help.
- Contributes to digital literacy, safer behaviour and a more responsible online culture.

## 7. Limitations (honest list)

- **Prototype scale:** 4 modules, 9 scenarios, 20 quiz questions. Content is hand-written and not yet reviewed by security professionals or educators.
- **Password estimates are rough.** The checker is a heuristic, not a full tool such as zxcvbn. It assumes an offline attack at 10 billion guesses per second and uses a small common-password list.
- **Not a detector.** It *teaches* recognition but does not scan real emails, links or files. It must never be used to decide whether a real message is safe.
- **Local-only data.** Progress is per browser/device. Clearing browser data erases it, and there is no cross-device sync or real teacher dashboard.
- **English only**, and examples are India-centred (helplines, UPI). Other regions need localisation.
- **Self-reported effect.** Quiz gains over short periods show learning, not proven long-term behaviour change. The same questions repeat, so scores can rise through memorisation. A real evaluation needs a larger question bank and follow-up.
- **No formal accessibility audit** (e.g. screen-reader testing across devices) has been done yet.
- Helpline and reporting details change. They are shown with a reminder to verify.

## 8. Future scope

- Larger, regularly refreshed content with **question randomisation** and difficulty levels; community-contributed scenarios reviewed by experts.
- **Multilingual** support (Hindi, Marathi, Tamil and others) and audio for low-literacy users.
- **Teacher/class mode**: class codes, anonymous aggregated results, and assignable modules, built with a minimal-data backend and consent.
- More simulations: fake **QR payment**, fake **job-portal chat**, voice-call (vishing) scripts and deepfake/AI-voice scam examples.
- A **browser extension or WhatsApp-style “paste a suspicious message”** helper that explains red flags *locally* without sending content anywhere.
- Proper password-strength library (e.g. zxcvbn) and an offline-ready **PWA** install.
- Gamification: streaks, classroom leaderboards (opt-in), certificates.
- Partnerships with colleges, NGOs and cyber-cell awareness programmes; a formal pre/post study to measure behaviour change.
- Accessibility audit and screen-reader testing.

---

## 9. Suggested plan for a 4-person student team (4 weeks)

| Week | Focus | Roles |
|---|---|---|
| 1 | Research real scams, write 4 module outlines, sketch screens | Content lead + Designer |
| 2 | Build shell, navigation, Learn module and quiz | Two developers |
| 3 | Phishing Lab, Password Coach, Safety Plan, Emergency, dashboard | Developers + Content lead |
| 4 | Test with 10–20 students, fix issues, record before/after quiz results and feedback, prepare demo | Everyone (tester/presenter) |

### Testing checklist
- [ ] Opens by double-clicking `index.html`; no console errors.
- [ ] Works at phone width (≈360–400px) and on desktop.
- [ ] Every module can be completed and un-completed.
- [ ] Lab: each scenario shows feedback; link preview reveals the real destination.
- [ ] Password Coach: `password`, `P@ssw0rd1`, `Rahul2004` rated weak; a 5-word passphrase rated strong; nothing appears in `localStorage` (DevTools → Application) except progress.
- [ ] Quiz: wrong answers appear with explanations; "Retry missed" works; scores appear on Home.
- [ ] Reset progress clears everything.
- [ ] Keyboard only: you can reach and use every control.

*All content is for education. Examples are fictional. If you are a victim of fraud, use the Emergency tab and contact your bank and official cybercrime services immediately.*
