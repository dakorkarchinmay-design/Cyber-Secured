/* CyberSafe sample content.
   Everything here is FICTIONAL: brands, people, numbers and websites are invented
   (".example" domains cannot exist on the real internet). Edit freely to add content. */
window.CYBERSAFE_DATA = {

  /* ------------------------------------------------------------------ */
  /* 1. LEARNING MODULES                                                  */
  /* ------------------------------------------------------------------ */
  modules: [
    {
      id: 'phishing', title: 'Spot Phishing', icon: '🎣', minutes: 5,
      blurb: 'Recognise fake emails, texts, links and websites before they trick you.',
      lessons: [
        { h: 'What is phishing?',
          p: 'Phishing is when a criminal pretends to be someone you trust (a bank, your college, a delivery company, even a friend) to trick you into clicking a link, opening a file or sharing private details. It arrives by email, SMS (“smishing”), phone calls (“vishing”) and chat apps.' },
        { h: 'Five red flags',
          list: ['Urgency or threats: “Act in 24 hours or your account is blocked.”',
                 'Mismatch: the sender name looks right, but the email address or link is slightly different.',
                 'Generic greeting: “Dear Customer” instead of your name.',
                 'Unexpected attachments or links, especially files ending in .html, .zip or .exe.',
                 'Requests for passwords, OTPs, PINs or card details. Real companies never ask for these.'],
          tip: 'One red flag is enough to pause. You do not need to find all five.' },
        { h: 'Check before you click',
          list: ['Press and hold (phone) or hover (computer) on a link to preview where it really goes.',
                 'Read the domain: the real site name is the part just before the first single “/”. In “login.unitybank.example/help” the site is unitybank.example. In “unitybank.example-login.com” the site is example-login.com, a look-alike.',
                 'Watch for swaps like rn for m, 0 for o, or extra hyphens.',
                 'Skip the link: open the official app or type the website address yourself.'] },
        { h: 'Fake websites',
          p: 'Criminals copy the look of real login pages. The padlock only means the connection is encrypted, not that the site is honest. Always check the address, and never log in from a link in a message.' }
      ],
      checklist: ['Find one email with a link and preview the link without clicking.',
                  'Save your bank and college portal as bookmarks or official apps.',
                  'Find the “Report phishing” option in your email app.']
    },
    {
      id: 'passwords', title: 'Password Power', icon: '🔑', minutes: 5,
      blurb: 'Create strong, unique passwords and add a second lock with 2-step verification.',
      lessons: [
        { h: 'Length beats cleverness',
          p: 'Every extra character multiplies the work for a guesser. A long, random-word passphrase like “purple-tractor-moon-lamp-river” is easier to remember and far harder to crack than “P@ssw0rd1”. Aim for 14+ characters. Never use an example from a lesson as a real password.' },
        { h: 'One account, one password',
          p: 'Hackers steal passwords from one site and try them everywhere (“credential stuffing”). If you reuse a password, one leak can open your email, social media and payments.' },
        { h: 'Use a password manager',
          p: 'A password manager creates and remembers unique passwords for you. You only memorise one strong master passphrase. The manager built into your browser or phone is a fine start.' },
        { h: 'Add a second lock (2FA)',
          p: 'Two-step verification asks for a second proof, such as a code from an authenticator app, after your password. Prefer an authenticator app or security key over SMS codes when you can, and keep backup codes somewhere offline.' },
        { h: 'The golden rule',
          p: 'Never share passwords or OTPs with anyone: not friends, not “support staff”, not even a teacher. Real services never ask for them.' }
      ],
      checklist: ['Turn on 2-step verification for your main email account.',
                  'Replace one reused password with a unique passphrase.',
                  'Open the Password Coach and try the generator.']
    },
    {
      id: 'scams', title: 'Scam Radar', icon: '🚨', minutes: 6,
      blurb: 'Fake jobs, UPI fraud, OTP scams and social engineering, explained simply.',
      lessons: [
        { h: 'Fake job & internship offers',
          list: ['They ask for a “registration”, “training” or “security” fee. Real employers never charge you to hire you.',
                 'Interviews happen only on chat apps, and the pay is far too high for easy work (“earn ₹5,000/day by liking videos”).',
                 'They want ID documents, bank details or an OTP before any offer letter.',
                 'The email comes from a free address while claiming to be a big company.'],
          tip: 'Search the company name + “scam”, and check its official careers page.' },
        { h: 'UPI & payment fraud',
          list: ['You never need your UPI PIN to receive money. If a screen asks for the PIN, you are sending money.',
                 '“I sent money by mistake, please return it”: scammers send a collect request or a fake alert. Check your real bank app, and return money only through your bank.',
                 'Scanning a QR code is for paying, not for receiving.',
                 'Fake customer-care numbers show up in search results and social media. Use only the number inside the official app.'] },
        { h: 'OTP scams',
          p: 'An OTP is the key to your money or account. Anyone who asks for it, even politely and even “from your bank”, is a scammer. “KYC update”, “prize claim” and “delivery fee” calls all end with the same request: read out the OTP.',
          tip: 'Hang up. Call back using the number printed on your card or inside the official app.' },
        { h: 'Social engineering',
          p: 'Scammers hack people, not computers. They use authority (“I’m from the bank”), urgency (“in 10 minutes”), fear (“your account is hacked”) or greed (“you’ve won!”). Slow down and verify through a second channel you trust.' },
        { h: 'Remote access & blackmail',
          p: 'Never install screen-sharing or remote-control apps because a caller asks; they can see your OTPs and control your phone. If someone threatens to share your photos or chats, do not pay. Save evidence and open the Emergency tab.' }
      ],
      checklist: ['Say it out loud: “I never share OTPs or UPI PINs.”',
                  'Save your bank’s official helpline from its app.',
                  'Tell a friend about one scam you learned today.']
    },
    {
      id: 'privacy', title: 'Privacy Shield', icon: '🛡️', minutes: 5,
      blurb: 'Control what you share on social media, in apps and on public Wi-Fi.',
      lessons: [
        { h: 'Your digital footprint',
          p: 'Everything you post can be copied, searched and combined. A birthday + college name + a photo of your ID card can be enough for someone to pretend to be you.' },
        { h: 'Social media settings',
          list: ['Make accounts private or “friends only”.',
                 'Hide your phone number, email and birthday.',
                 'Turn off live location sharing and location tags on photos.',
                 'Review tagged photos before they appear on your profile.',
                 'Think before posting ID cards, tickets, boarding passes or exam hall tickets. They contain codes and personal details.'] },
        { h: 'App permissions',
          p: 'Apps often ask for more than they need. A torch app does not need your contacts. Choose “While using the app” for location, deny SMS and contacts unless essential, review permissions every few months, and install apps only from official stores.' },
        { h: 'Public Wi-Fi',
          p: 'Open networks can be watched or faked. Avoid banking and logins on public Wi-Fi; use mobile data instead, and turn off auto-connect.' },
        { h: 'Be kind and responsible',
          p: 'Privacy goes both ways. Ask before posting photos of friends, do not share private chats, and never join in harassment. Responsible technology use protects everyone.' }
      ],
      checklist: ['Switch one social account to private.',
                  'Open phone Settings → Permissions and check who can use Location.',
                  'Delete one old post that shows personal details.']
    }
  ],

  /* ------------------------------------------------------------------ */
  /* 2. PHISHING LAB SCENARIOS (6 scams, 3 legitimate)                    */
  /* ------------------------------------------------------------------ */
  scenarios: [
    { id: 's1', kind: 'email', phish: true,
      context: 'You get this email while studying. You do have an account at Unity Bank.',
      from: 'Unity Bank Security <alerts@unitybank-secure.example>',
      subject: 'URGENT: Account will be blocked in 24 hours',
      body: ['Dear Customer,', 'We detected unusual activity on your account. To avoid permanent blocking you must verify your identity within 24 hours.'],
      link: { text: 'Verify my account now', href: 'http://unitybank-secure-login.example/verify' },
      verdict: 'Classic bank phishing: it uses fear and a deadline to push you onto a fake login page.',
      flags: [
        { t: 'Urgent threat', why: 'Scammers create panic so you act before thinking.' },
        { t: 'Generic greeting', why: '“Dear Customer”: your real bank knows your name.' },
        { t: 'Look-alike domain', why: 'The real site is unitybank.example. This one is unitybank-secure-login.example, a different website.' },
        { t: 'Link uses http://', why: 'No encryption. Banks use https and never ask for logins through email links.' }
      ],
      tip: 'Open your bank’s official app or type its address yourself. Never use the link.' },

    { id: 's2', kind: 'chat', phish: false,
      context: 'You just tapped “Log in” in your Unity Bank app, and a text arrives seconds later.',
      sender: 'AX-UNITYB (bank sender ID)',
      messages: ['Your Unity Bank OTP is 482913. Valid for 10 minutes. Do not share this code with anyone, including bank staff.'],
      verdict: 'Legitimate: you started the action and the message only gives a code to type into your own app.',
      flags: [
        { t: 'You triggered it', why: 'You were logging in right then. Unexpected OTPs are the warning sign.' },
        { t: 'No link, no request', why: 'It asks you to do nothing except use the code yourself.' },
        { t: 'Warns you not to share', why: 'Real OTP messages say this. Scam messages never do.' }
      ],
      tip: 'The danger starts only if someone asks you to read the OTP out. Never do that.' },

    { id: 's3', kind: 'chat', phish: true,
      context: 'A stranger messages you on a chat app.',
      sender: '+91 90000 12345 (not in your contacts)',
      messages: ['Hi! We found your profile 😊 Work from home: just like videos and earn ₹5,000 per day 💰',
                 'No experience needed. Pay a one-time registration fee of ₹499 (100% refundable) to activate your account.',
                 'Reply FAST, only 3 slots left today!'],
      verdict: 'Fake job scam. The “fee” is the scam, and later requests usually grow bigger.',
      flags: [
        { t: 'Too good to be true', why: 'Huge pay for tiny effort is the biggest tell of fake jobs.' },
        { t: 'Upfront fee', why: 'Real employers never charge to hire you, even if “refundable”.' },
        { t: 'Pressure to hurry', why: '“Only 3 slots” is made-up scarcity.' },
        { t: 'Unknown sender', why: 'No company name, no official email, no interview.' }
      ],
      tip: 'Block, report, and do not pay. Check offers on the company’s official careers page.' },

    { id: 's4', kind: 'site', phish: true,
      context: 'A message says “Hostel fee pending: log in here now”. You tap the link and see this page.',
      url: 'https://fictionaluniversity-portal.example/login',
      pageTitle: 'Fictional University – Student Portal',
      fields: ['Student ID', 'Password'], button: 'Log in',
      verdict: 'A fake copy of the college portal built to steal student logins.',
      flags: [
        { t: 'Wrong domain', why: 'The real portal is portal.fictionaluniversity.example. This is a different website with a similar name.' },
        { t: 'Reached through a message link', why: 'Criminals send links so you never check the address.' },
        { t: 'Padlock proves nothing', why: 'Even fake sites can use https. It only means the connection is encrypted.' },
        { t: 'Pressure from the message', why: '“Pending fee: log in now” is urgency again.' }
      ],
      tip: 'Type the portal address yourself or use your bookmark. Never log in from a link.' },

    { id: 's5', kind: 'site', phish: false,
      context: 'You opened your saved bookmark for the college portal.',
      url: 'https://portal.fictionaluniversity.example/login',
      pageTitle: 'Fictional University – Student Portal',
      fields: ['Student ID', 'Password'], button: 'Log in',
      verdict: 'Legitimate: this is the real portal, reached the safe way.',
      flags: [
        { t: 'Correct domain', why: 'The site name is fictionaluniversity.example. “portal” in front is just a section of the real site.' },
        { t: 'You chose how to get here', why: 'You used a bookmark, not a link from a message.' },
        { t: 'Nothing unusual is asked', why: 'A normal login form, with no extra personal details or payment request.' }
      ],
      tip: 'Bookmarks and official apps are the safest doors to your important accounts.' },

    { id: 's6', kind: 'chat', phish: true,
      context: 'You get this from an unknown number right after a “payment received” style message appears.',
      sender: 'Unknown number',
      messages: ['Sir sorry, I sent ₹2,000 to your UPI by mistake 🙏',
                 'I have sent you a request. Please approve it to return the money. I need it urgently.'],
      verdict: 'UPI “wrong transfer” scam. The “request” is a collect request that takes money out of your account.',
      flags: [
        { t: '“Approve the request”', why: 'Approving a request and entering your PIN sends money. You never need a PIN to receive money.' },
        { t: 'Emotional pressure', why: 'Urgency and politeness make you act quickly and feel guilty.' },
        { t: 'Unverified claim', why: 'Check your real bank app. A genuine credit shows there, not in a chat.' },
        { t: 'Unknown sender', why: 'Real mistakes are resolved through the bank, not by approving random requests.' }
      ],
      tip: 'Decline the request. If money really arrived, return it only through your bank’s process.' },

    { id: 's7', kind: 'email', phish: true,
      context: 'An email lands in your inbox. You never applied for any scholarship.',
      from: 'Scholarship Board <winner@gov-scholarship-awards.example>',
      subject: '🎉 You have been selected for ₹50,000 scholarship!',
      body: ['Congratulations!', 'You were chosen without applying. To receive the grant, submit your ID number and bank account number, and pay a ₹1,200 processing fee.'],
      link: { text: 'Claim scholarship', href: 'http://gov-scholarship-awards.example/claim' },
      verdict: 'Prize/scholarship scam that collects your identity and money.',
      flags: [
        { t: 'You “won” something you did not enter', why: 'Real scholarships need an application.' },
        { t: 'Fee to receive money', why: 'Genuine awards never charge a fee to pay you.' },
        { t: 'Asks for ID and bank details', why: 'This is identity theft in progress.' },
        { t: 'Official-sounding name only', why: 'The domain is not a government or college address.' }
      ],
      tip: 'Check scholarships on official government or college websites you find yourself.' },

    { id: 's8', kind: 'email', phish: true,
      context: 'You get this email. It contains no link or attachment at all.',
      from: 'IT Helpdesk <helpdesk@fictionaluniversity-it.example>',
      subject: 'Mailbox full: reply with your login',
      body: ['Your mailbox is 99% full and will be deleted today.', 'To keep your account, reply to this email with your username and password.'],
      verdict: 'Credential theft by reply. Phishing does not always need a link.',
      flags: [
        { t: 'Asks for your password', why: 'IT teams never need your password. They can reset it themselves.' },
        { t: 'Threat + deadline', why: '“Deleted today” is manufactured urgency.' },
        { t: 'Sender domain differs', why: 'The college uses fictionaluniversity.example, not fictionaluniversity-it.example.' }
      ],
      tip: 'Never send a password by email, chat or phone. Report the message to your real IT team.' },

    { id: 's9', kind: 'email', phish: false,
      context: 'You ordered a USB-C cable from ShopKart two days ago.',
      from: 'ShopKart Orders <orders@shopkart.example>',
      subject: 'Your order #SK-20481 has shipped',
      body: ['Hi Riya,', 'Good news: your order of “USB-C cable (2 pack)” has shipped and should arrive by Friday.', 'You can track it any time in the ShopKart app under My Orders.'],
      verdict: 'Legitimate: expected, personal, and asks for nothing sensitive.',
      flags: [
        { t: 'You expected it', why: 'It matches an order you actually placed.' },
        { t: 'Nothing sensitive requested', why: 'No password, OTP, card number or payment.' },
        { t: 'Points you to the app', why: 'It does not push you through a link. You can check inside your own account.' }
      ],
      tip: 'When unsure, open the app directly and look for the order there instead of using the email.' }
  ],

  /* ------------------------------------------------------------------ */
  /* 3. QUIZ QUESTIONS (cat matches a module id)                          */
  /* ------------------------------------------------------------------ */
  questions: [
    { id: 'q1', cat: 'phishing', q: 'Which is the strongest sign that an email is phishing?',
      options: ['It has a company logo', 'It pressures you to log in through a link right now', 'It was sent on a weekday', 'It is written in English'], answer: 1,
      explain: 'Logos are easy to copy. Pressure plus a login link is the classic phishing combination.' },
    { id: 'q2', cat: 'phishing', q: 'A link says “unitybank.example” but previews as “unitybank-login.example”. What should you do?',
      options: ['Click it because the text looks right', 'Don’t click; open the bank’s app or type the address yourself', 'Forward it to friends', 'Reply asking if it is real'], answer: 1,
      explain: 'The preview shows the real destination. A different domain means a different website. Go in through the app or by typing the address.' },
    { id: 'q3', cat: 'phishing', q: 'What does the padlock (https) in the address bar mean?',
      options: ['The site is definitely safe', 'The connection is encrypted, but the site could still be fake', 'The site is owned by a bank', 'The site has no viruses'], answer: 1,
      explain: 'Encryption protects data in transit. Criminals can get https for fake sites too. Check the domain name.' },
    { id: 'q4', cat: 'phishing', q: 'Which is the real “unitybank.example” website?',
      options: ['unitybank.example.verify-now.example', 'unity-bank.example', 'login.unitybank.example', 'unitybank.example-login.com'], answer: 2,
      explain: 'Read the domain just before the first single “/”. In login.unitybank.example, “login” is only a section of unitybank.example. The others are different domains.' },
    { id: 'q5', cat: 'phishing', q: 'You receive an unexpected “Invoice.html” attachment from a stranger. Best action?',
      options: ['Open it to see what it is', 'Download and forward it to a friend', 'Don’t open it; delete or report it', 'Open it on public Wi-Fi'], answer: 2,
      explain: 'HTML attachments can show fake login pages. Unknown attachments are safest left unopened.' },
    { id: 'q6', cat: 'phishing', q: 'What is “smishing”?',
      options: ['Phishing sent by SMS or text message', 'A type of antivirus', 'Phishing by phone call only', 'A password manager'], answer: 0,
      explain: 'Smishing = SMS + phishing. The same red flags apply: urgency, strange links and requests for private details.' },

    { id: 'q7', cat: 'passwords', q: 'Which password is generally the strongest?',
      options: ['P@ssw0rd!', 'Rahul2004', 'purple-tractor-moon-bicycle-lamp', 'qwerty12345'], answer: 2,
      explain: 'Length and randomness win. The first, second and fourth are common or predictable patterns attackers try first.' },
    { id: 'q8', cat: 'passwords', q: 'Why is reusing one password on many sites risky?',
      options: ['It’s fine if the password is long', 'One leak can unlock all your accounts', 'Websites forbid it', 'It makes passwords expire faster'], answer: 1,
      explain: 'Attackers reuse leaked passwords across sites (“credential stuffing”).' },
    { id: 'q9', cat: 'passwords', q: 'What’s the easiest way to have a unique password for every account?',
      options: ['Write them all on a sticky note on your laptop', 'Use a password manager', 'Use your pet’s name plus a number', 'Change one letter each time'], answer: 1,
      explain: 'A password manager creates and stores unique passwords, so you only remember one strong master passphrase.' },
    { id: 'q10', cat: 'passwords', q: 'Which kind of 2-step verification is generally safer?',
      options: ['Codes by SMS', 'An authenticator app or security key', 'Answering “What’s your pet’s name?”', 'No 2-step verification'], answer: 1,
      explain: 'SMS codes can be intercepted through SIM-swap attacks. Authenticator apps and security keys are harder to steal.' },
    { id: 'q11', cat: 'passwords', q: 'Who should you share your passwords with?',
      options: ['Close friends', 'IT helpdesk over the phone', 'Nobody', 'Anyone from the bank'], answer: 2,
      explain: 'Legitimate organisations never ask for your password. Anyone asking is a red flag.' },

    { id: 'q12', cat: 'scams', q: 'When do you enter your UPI PIN?',
      options: ['To receive money', 'Only to send money or check your balance', 'To confirm a prize', 'Whenever a stranger asks'], answer: 1,
      explain: 'A PIN is never needed to receive money. If a request asks for your PIN, money is leaving your account.' },
    { id: 'q13', cat: 'scams', q: 'A caller says he is from your bank and asks for an OTP to “stop fraud”. What do you do?',
      options: ['Share the OTP quickly', 'Hang up and call the number on your card or in the app', 'Share half the OTP', 'Ask him to prove it by saying your name'], answer: 1,
      explain: 'Banks never ask for OTPs. Scammers can already know your name, so call back using an official number.' },
    { id: 'q14', cat: 'scams', q: 'An internship offer asks for a ₹999 “refundable registration fee”. This is…',
      options: ['Normal for good companies', 'Likely a scam', 'A sign of a premium offer', 'Required by law'], answer: 1,
      explain: 'Genuine employers do not charge candidates. Fees (even “refundable”) are a top fake-job sign.' },
    { id: 'q15', cat: 'scams', q: 'What is social engineering?',
      options: ['Building social media apps', 'Manipulating people into giving up information or access', 'A type of computer virus', 'A privacy setting'], answer: 1,
      explain: 'Social engineering uses trust, fear, urgency or greed to trick people rather than hacking machines.' },
    { id: 'q16', cat: 'scams', q: 'A “support agent” asks you to install a screen-sharing app to process a refund. What now?',
      options: ['Install it to get your refund', 'Refuse; remote access lets them see OTPs and control your phone', 'Install it but cover the camera', 'Share only your bank app screen'], answer: 1,
      explain: 'Remote-access apps give full visibility and control. Refunds never need them.' },

    { id: 'q17', cat: 'privacy', q: 'A torch (flashlight) app asks for access to your contacts and location. What’s best?',
      options: ['Allow everything', 'Deny; it doesn’t need them', 'Allow only on weekends', 'Allow and then uninstall'], answer: 1,
      explain: 'Apps should get only the permissions they need for their purpose.' },
    { id: 'q18', cat: 'privacy', q: 'What’s the risk of posting a clear photo of your college ID publicly?',
      options: ['None; it’s just a card', 'Someone can use the details to impersonate you', 'Your phone will slow down', 'The photo will be deleted'], answer: 1,
      explain: 'IDs show your name, number and photo, handy for impersonation and fake accounts.' },
    { id: 'q19', cat: 'privacy', q: 'You’re at a café with free Wi-Fi. What should you avoid?',
      options: ['Reading the news', 'Logging in to banking or payments', 'Listening to music', 'Checking the weather'], answer: 1,
      explain: 'Open networks can be monitored or faked. Use mobile data for sensitive logins.' },
    { id: 'q20', cat: 'privacy', q: 'Which setting best protects a personal social media account?',
      options: ['Public profile with location tags', 'Private or friends-only, with tag review turned on', 'Share your phone number in the bio', 'Accept all follow requests'], answer: 1,
      explain: 'Limiting your audience and reviewing tags reduces what strangers and scammers can learn.' }
  ],

  /* ------------------------------------------------------------------ */
  /* 4. SAFETY ACTION PLAN                                                */
  /* ------------------------------------------------------------------ */
  /* p: 1 = Today, 2 = This week, 3 = This month */
  actions: {
    'manager':   { p: 1, time: '15 min', t: 'Set up a password manager (browser or phone built-in is fine) and save your email password first.' },
    'email-pw':  { p: 1, time: '10 min', t: 'Give your main email a long, unique passphrase. Email resets everything else.' },
    'unique':    { p: 2, time: '30 min', t: 'Replace reused passwords, starting with email, banking/UPI, social media and cloud storage.' },
    '2fa':       { p: 1, time: '10 min', t: 'Turn on 2-step verification (authenticator app preferred) for email, social media and payments.' },
    'backup':    { p: 3, time: '5 min',  t: 'Save backup codes for your important accounts somewhere offline.' },
    'pause':     { p: 2, time: 'Habit',  t: 'Practise “Pause, Check, Verify”: never act on an urgent message before checking in the official app or site.' },
    'typeurl':   { p: 2, time: '5 min',  t: 'Bookmark your bank and college portal; open them from the bookmark or app, not from links.' },
    'report':    { p: 3, time: '5 min',  t: 'Find how to report phishing in your email app and your college IT team’s reporting address.' },
    'jobcheck':  { p: 1, time: 'Habit',  t: 'Before replying to any job offer: search the company + “scam”, check its official website, and never pay a fee.' },
    'upi-rules': { p: 1, time: '2 min',  t: 'Memorise: you never enter a UPI PIN to receive money. Decline unknown collect requests.' },
    'upi-limit': { p: 2, time: '5 min',  t: 'Set a low daily UPI limit and turn on app lock in your payment apps.' },
    'otp':       { p: 1, time: '2 min',  t: 'Decide now: you never share OTPs, PINs or CVV with anyone, including “bank staff”.' },
    'social':    { p: 1, time: '10 min', t: 'Set social accounts to private/friends-only and hide your phone number and birthday.' },
    'tags':      { p: 2, time: '15 min', t: 'Turn on tag review, switch off location tags, and delete old posts showing ID cards, tickets or your location.' },
    'perms':     { p: 2, time: '10 min', t: 'Review app permissions: set Location, Camera and Mic to “While using”; deny contacts/SMS unless essential.' },
    'appclean':  { p: 3, time: '10 min', t: 'Uninstall apps you don’t use, and install new ones only from official stores.' },
    'wifi':      { p: 2, time: '3 min',  t: 'Avoid banking on public Wi-Fi, use mobile data, and turn off auto-connect to open networks.' },
    'updates':   { p: 2, time: '3 min',  t: 'Turn on automatic updates for your phone, laptop and apps.' },
    'oldacc':    { p: 3, time: '30 min', t: 'List old accounts (search your inbox for “welcome” emails) and delete the ones you no longer use.' },
    'sharedpc':  { p: 1, time: 'Habit',  t: 'On shared computers use a private window, fully sign out, and never save passwords.' },
    'lock':      { p: 1, time: '3 min',  t: 'Set a screen lock (PIN or biometric) with auto-lock after one minute or less.' },
    'findphone': { p: 3, time: '5 min',  t: 'Turn on “Find my device” and back up your phone so a loss is recoverable.' }
  },

  concerns: [
    { id: 'weakpw',  label: 'I reuse passwords or use simple ones',        actions: ['manager', 'email-pw', 'unique', '2fa'] },
    { id: 'no2fa',   label: 'I don’t use 2-step verification',            actions: ['2fa', 'backup'] },
    { id: 'links',   label: 'I tap links in messages quickly',             actions: ['pause', 'typeurl', 'report'] },
    { id: 'jobs',    label: 'I’m applying for jobs or internships online', actions: ['jobcheck', 'pause', 'report'] },
    { id: 'upi',     label: 'I use UPI or mobile payments often',          actions: ['upi-rules', 'otp', 'upi-limit', 'lock'] },
    { id: 'social',  label: 'My social media is mostly public',            actions: ['social', 'tags'] },
    { id: 'apps',    label: 'I install lots of apps',                      actions: ['perms', 'appclean', 'updates'] },
    { id: 'wifi',    label: 'I often use public Wi-Fi',                    actions: ['wifi', 'updates'] },
    { id: 'shared',  label: 'I use shared or lab computers',               actions: ['sharedpc', '2fa'] },
    { id: 'oldacc',  label: 'I have many old, unused accounts',            actions: ['oldacc', 'unique'] },
    { id: 'phone',   label: 'My phone isn’t locked or backed up',         actions: ['lock', 'findphone', 'updates'] }
  ],

  /* ------------------------------------------------------------------ */
  /* 5. EMERGENCY GUIDANCE                                                */
  /* ------------------------------------------------------------------ */
  emergency: {
    help: [
      { label: 'National Cyber Crime Helpline (India)', text: 'Call 1930', href: 'tel:1930' },
      { label: 'Report online (India)', text: 'cybercrime.gov.in', href: 'https://cybercrime.gov.in' },
      { label: 'Your bank', text: 'Use the number printed on your card or inside the official app, never one from a message or search result.' }
    ],
    helpNote: 'Helplines can change, so verify on official sites. The numbers above are for India; elsewhere, search for your country’s official cybercrime reporting service.',
    guides: [
      { id: 'hacked', icon: '🔓', title: 'My account was hacked',
        sub: 'Social media, email or any account you can’t control',
        steps: [
          'If you can still log in, change the password right now to a new, unique one.',
          'If you can’t, use the service’s “Forgot password / account recovery” page (type the address yourself).',
          'Secure your email first. Whoever controls your email can reset everything else.',
          'Turn on 2-step verification and sign out of all other devices and sessions.',
          'Check recovery email/phone and email forwarding rules, and undo anything you didn’t set.',
          'Change the password on any other account that used the same password.',
          'Warn friends not to click links or send money if they get odd messages from you.',
          'Report the hijacked account to the platform and run a security scan on your device.'],
        dont: ['Don’t pay anyone who offers to “recover” your account.', 'Don’t reuse the old password with a small change.'] },

      { id: 'clicked', icon: '🎣', title: 'I clicked a bad link or opened a file',
        sub: 'Phishing email, SMS or fake website',
        steps: [
          'Disconnect from Wi-Fi/mobile data if you downloaded or installed something.',
          'Stop typing anything into the page. If you already entered a password, change it right away on the real site (type the address) and anywhere you reused it.',
          'If you entered card or banking details, call your bank on its official number and block the card or account access.',
          'Run a security scan, and remove any app or extension you were prompted to install.',
          'Turn on 2-step verification and review recent sign-in activity.',
          'Report it: use “Report phishing” or forward it to your IT team, then delete the message.',
          'Tell someone. Speed helps, and nobody will blame you.'],
        dont: ['Don’t hide it. The first hour matters most.', 'Don’t reply to the sender.'] },

      { id: 'money', icon: '💸', title: 'I lost money or shared an OTP / UPI PIN',
        sub: 'UPI fraud, card fraud, fake job fee, OTP scam',
        steps: [
          'Call your bank’s official helpline now and ask to block the card, UPI or account access.',
          'In India, call 1930 or report at cybercrime.gov.in as soon as possible. Quick reports give the best chance of stopping the transfer.',
          'Write down the amount, time, transaction ID, and the receiver’s UPI ID/number/account. Take screenshots of chats.',
          'Change your UPI PIN and banking passwords, and remove any remote-access app you were asked to install.',
          'File a complaint with your local police or cyber cell if advised, bringing your evidence.',
          'Tell a trusted adult, teacher or family member. You’re not alone and it’s not your fault.'],
        dont: ['Don’t pay “release”, “tax” or “recovery” fees. That’s a second scam.', 'Don’t trust “recovery agents” who contact you first.'] },

      { id: 'blackmail', icon: '🆘', title: 'Someone is threatening or blackmailing me',
        sub: 'Threats to share photos, chats or personal details',
        steps: [
          'Stay calm. You are not at fault. Don’t pay or send more photos or money.',
          'Stop replying, but don’t delete anything yet. Screenshot messages, usernames, profile links and payment requests.',
          'Block the account and report it on the platform.',
          'Tell a trusted person: a friend, family member, teacher or counsellor.',
          'Report to cybercrime.gov.in or call 1930 (India), or contact the police. If intimate images are involved, services like StopNCII.org can help stop them spreading.',
          'Tighten privacy: make accounts private and change your passwords.'],
        dont: ['Don’t pay. It rarely stops the threats.', 'Don’t face it alone.'] },

      { id: 'device', icon: '📱', title: 'I lost my phone or laptop',
        sub: 'Lost, stolen or left behind',
        steps: [
          'Use “Find my device” to locate, lock or erase it.',
          'Call your mobile operator to block the SIM and get a replacement.',
          'From another device, change passwords for email, banking and social media, and sign out of the lost device.',
          'Contact your bank to pause UPI/cards if banking apps were on the device.',
          'File a police report. You may need it for the SIM, insurance or college records.'],
        dont: ['Don’t keep using accounts as if nothing happened. Lock them first.'] }
    ]
  },

  /* ------------------------------------------------------------------ */
  /* 6. PASSWORD COACH DATA (all local; nothing is sent anywhere)         */
  /* ------------------------------------------------------------------ */
  commonPasswords: ['password', 'password1', 'passw0rd', 'admin', 'admin123', 'welcome', 'welcome123', 'letmein', 'iloveyou',
    'qwerty', 'qwerty123', 'abc123', '123456', '1234567', '12345678', '123456789', '1234567890', '111111', '000000', '654321',
    '1q2w3e', 'qazwsx', 'monkey', 'dragon', 'football', 'cricket', 'sachin', 'india123', 'sunshine', 'princess', 'superman',
    'shadow', 'master', 'login', 'student', 'college', 'test123', 'changeme'],

  words: ['apple', 'anchor', 'bamboo', 'basket', 'beacon', 'berry', 'bicycle', 'bridge', 'button', 'cactus', 'camel', 'candle',
    'canyon', 'carpet', 'castle', 'cedar', 'cherry', 'cinema', 'clover', 'cobweb', 'comet', 'copper', 'coral', 'cotton',
    'crystal', 'daisy', 'desert', 'dolphin', 'eagle', 'ember', 'falcon', 'feather', 'fiddle', 'forest', 'fossil', 'galaxy',
    'garden', 'ginger', 'glacier', 'goblet', 'granite', 'guitar', 'hammer', 'harbor', 'hazel', 'helmet', 'island', 'jacket',
    'jasmine', 'jungle', 'kettle', 'kitten', 'ladder', 'lantern', 'lemon', 'lizard', 'magnet', 'mango', 'maple', 'marble',
    'meadow', 'mirror', 'monsoon', 'mountain', 'noodle', 'nutmeg', 'oasis', 'orchid', 'otter', 'paddle', 'pebble', 'pepper',
    'pillow', 'planet', 'pocket', 'pumpkin', 'puzzle', 'quartz', 'rabbit', 'rainbow', 'river', 'rocket', 'saddle', 'sapphire',
    'shadow', 'silver', 'spiral', 'sponge', 'squirrel', 'sunset', 'tablet', 'teapot', 'thunder', 'tiger', 'timber', 'tomato',
    'tractor', 'trumpet', 'tulip', 'tunnel', 'turtle', 'umbrella', 'valley', 'velvet', 'violin', 'walnut', 'whistle', 'willow',
    'window', 'winter', 'wizard', 'yogurt', 'zebra', 'zipper']
};
