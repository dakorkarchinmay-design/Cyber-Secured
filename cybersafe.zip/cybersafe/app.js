/* CyberSafe app logic.
   - No network calls. No passwords, OTPs or personal data are stored.
   - Only learning progress (module ticks, quiz scores, lab accuracy, plan ticks,
     optional feedback) is saved in this browser's localStorage. */
(function () {
  'use strict';

  const D = window.CYBERSAFE_DATA;
  const KEY = 'cybersafe_progress_v1';
  const app = document.getElementById('app');
  const CAT = { phishing: 'Phishing', passwords: 'Passwords', scams: 'Scams', privacy: 'Privacy' };

  /* ------------------------------ helpers ------------------------------ */
  const $ = (sel, root) => (root || document).querySelector(sel);
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const shuffle = a => { const r = a.slice(); for (let i = r.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [r[i], r[j]] = [r[j], r[i]]; } return r; };
  const pct = (a, b) => (b ? Math.round((100 * a) / b) : 0);
  const fmtDate = t => new Date(t).toLocaleDateString(undefined, { day: 'numeric', month: 'short' });
  const bar = p => `<div class="bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${p}"><span style="width:${p}%"></span></div>`;

  /* ------------------------------- state ------------------------------- */
  const blank = () => ({ modules: {}, phish: { attempts: 0, correct: 0, sessions: [] }, quizzes: [], plan: { concerns: [], done: {} }, feedback: [], flags: {} });
  function load() {
    try { const raw = JSON.parse(localStorage.getItem(KEY)); return raw ? Object.assign(blank(), raw) : blank(); }
    catch (e) { return blank(); }
  }
  let S = load();
  function save() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) { /* storage blocked: progress just won't persist */ } }

  function stats() {
    const qs = S.quizzes;
    const pc = q => pct(q.score, q.total);
    const modsDone = D.modules.filter(m => S.modules[m.id]).length;
    return {
      modsDone, modsTotal: D.modules.length, modPct: pct(modsDone, D.modules.length),
      phAttempts: S.phish.attempts, phAcc: S.phish.attempts ? pct(S.phish.correct, S.phish.attempts) : null,
      quizCount: qs.length,
      firstQuiz: qs.length ? pc(qs[0]) : null,
      lastQuiz: qs.length ? pc(qs[qs.length - 1]) : null,
      bestQuiz: qs.length ? Math.max.apply(null, qs.map(pc)) : 0,
      improve: qs.length > 1 ? pc(qs[qs.length - 1]) - pc(qs[0]) : null
    };
  }

  const BADGES = [
    { icon: '🌱', name: 'First Steps', desc: 'Complete a learning module', ok: s => s.modsDone >= 1 },
    { icon: '🎓', name: 'Cyber Scholar', desc: 'Complete all modules', ok: s => s.modsDone === s.modsTotal },
    { icon: '🔍', name: 'Phish Spotter', desc: '80%+ accuracy over 5+ lab answers', ok: s => s.phAttempts >= 5 && s.phAcc >= 80 },
    { icon: '📈', name: 'Quiz Climber', desc: 'Beat your first quiz score', ok: s => s.improve !== null && s.improve > 0 },
    { icon: '🏆', name: 'Quiz Ace', desc: 'Score 90%+ on a quiz', ok: s => s.bestQuiz >= 90 },
    { icon: '🗺️', name: 'Plan Maker', desc: 'Build your safety plan', ok: () => S.plan.concerns.length > 0 },
    { icon: '🔑', name: 'Password Practice', desc: 'Try the Password Coach', ok: () => !!S.flags.pw }
  ];

  function nextStep(st) {
    if (st.modsDone === 0) return { t: 'Start with “Spot Phishing”. It takes about 5 minutes.', href: '#/learn/phishing', cta: 'Open lesson' };
    if (!S.quizzes.length) return { t: 'Take your baseline quiz so you can see your progress later.', href: '#/quiz', cta: 'Start quiz' };
    if (st.phAttempts < 5) return { t: 'Try the Phishing Lab and test your eye on realistic fake messages.', href: '#/practice/phish', cta: 'Open Phishing Lab' };
    if (!S.plan.concerns.length) return { t: 'Build your personal Safety Plan in two minutes.', href: '#/practice/plan', cta: 'Build my plan' };
    const last = S.quizzes[S.quizzes.length - 1];
    if (last.missed && last.missed.length) {
      const count = {};
      last.missed.forEach(id => { const q = D.questions.find(x => x.id === id); if (q) count[q.cat] = (count[q.cat] || 0) + 1; });
      const weakest = Object.keys(count).sort((a, b) => count[b] - count[a])[0];
      if (weakest) return { t: `Your last quiz showed room to grow in ${CAT[weakest]}. Review that module.`, href: '#/learn/' + weakest, cta: 'Review module' };
    }
    const todo = D.modules.find(m => !S.modules[m.id]);
    if (todo) return { t: `Continue with “${todo.title}”.`, href: '#/learn/' + todo.id, cta: 'Open lesson' };
    return { t: 'Great work! Retake a quiz to keep your skills sharp.', href: '#/quiz', cta: 'Take a quiz' };
  }

  /* ------------------------------- router ------------------------------ */
  const VIEWS = { home: renderHome, learn: renderLearn, practice: renderPractice, quiz: renderQuiz, sos: renderSOS };
  let current = { name: 'home', sub: '' };

  function setView(html, focusSel) {
    app.innerHTML = html;
    const t = (focusSel && $(focusSel, app)) || $('h1', app) || $('h2', app);
    if (t) { t.setAttribute('tabindex', '-1'); t.focus(); }
    if (!focusSel) window.scrollTo(0, 0);
    if (current.name === 'practice' && current.sub === 'password') updatePw();
  }
  function render(focusSel) { setView((VIEWS[current.name] || renderHome)(current.sub), focusSel); }
  function route() {
    const parts = (location.hash.replace(/^#\/?/, '') || 'home').split('/');
    current = { name: VIEWS[parts[0]] ? parts[0] : 'home', sub: parts[1] || '' };
    document.querySelectorAll('[data-nav]').forEach(a => {
      if (a.dataset.nav === current.name) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
    });
    render();
  }
  window.addEventListener('hashchange', route);

  /* -------------------------------- HOME ------------------------------- */
  function trend(vals) {
    if (vals.length < 2) return '<p class="muted">Take at least two quizzes to see your trend.</p>';
    const w = 240, h = 70, pad = 8;
    const pts = vals.map((v, i) => [pad + (i * (w - 2 * pad)) / (vals.length - 1), h - pad - (v / 100) * (h - 2 * pad)]);
    return `<svg class="trend" viewBox="0 0 ${w} ${h}" role="img" aria-label="Quiz scores over time: ${vals.join('%, ')}%">
      <polyline points="${pts.map(p => p.join(',')).join(' ')}" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"/>
      ${pts.map(p => `<circle cx="${p[0]}" cy="${p[1]}" r="3.5" fill="currentColor"/>`).join('')}</svg>`;
  }

  function renderHome() {
    const st = stats(), nx = nextStep(st);
    const fbN = S.feedback.length;
    const fbAvg = fbN ? (S.feedback.reduce((a, f) => a + f.rating, 0) / fbN).toFixed(1) : null;
    const scores = S.quizzes.slice(-8).map(q => pct(q.score, q.total));
    const improveTxt = st.improve === null ? 'Take 2+ quizzes to measure improvement.'
      : st.improve > 0 ? `▲ +${st.improve} points since your first quiz` : st.improve < 0 ? `▼ ${st.improve} points vs your first quiz` : 'Same as your first quiz';
    const badges = BADGES.map(b => { const ok = b.ok(st); return `<li class="badge ${ok ? 'on' : ''}"><span aria-hidden="true">${b.icon}</span><div><strong>${b.name}</strong><small>${b.desc}</small><small>${ok ? '✓ Earned' : 'Locked'}</small></div></li>`; }).join('');
    return `
      <section class="hero">
        <h1>Stay one step ahead online</h1>
        <p>Short lessons, realistic (fictional) attacks and quick quizzes, made for students, teachers and first-time internet users.</p>
        <div class="row"><a class="btn primary" href="#/learn">Start learning</a><a class="btn" href="#/practice/phish">Try the Phishing Lab</a></div>
      </section>

      <section class="card" aria-labelledby="next-h">
        <p class="kicker" id="next-h">Your next step</p>
        <p><strong>${esc(nx.t)}</strong></p>
        <a class="btn primary" href="${nx.href}">${esc(nx.cta)}</a>
      </section>

      <h2>Your progress</h2>
      <section class="grid four" aria-label="Progress dashboard">
        <div class="card"><p class="kicker">Modules completed</p><p class="big-num">${st.modsDone}/${st.modsTotal}</p>${bar(st.modPct)}<small class="muted">${st.modPct}% completion rate</small></div>
        <div class="card"><p class="kicker">Phishing accuracy</p><p class="big-num">${st.phAcc === null ? '–' : st.phAcc + '%'}</p>${bar(st.phAcc || 0)}<small class="muted">${st.phAttempts} lab answer${st.phAttempts === 1 ? '' : 's'}</small></div>
        <div class="card"><p class="kicker">Latest quiz</p><p class="big-num">${st.lastQuiz === null ? '–' : st.lastQuiz + '%'}</p>${bar(st.lastQuiz || 0)}<small class="muted">${esc(improveTxt)}</small></div>
        <div class="card"><p class="kicker">Your feedback</p><p class="big-num">${fbAvg === null ? '–' : fbAvg + '★'}</p><small class="muted">${fbN} rating${fbN === 1 ? '' : 's'} given</small></div>
      </section>

      <section class="card"><h2>Quiz trend</h2>${trend(scores)}</section>

      <section class="card"><h2>Badges</h2><ul class="badges">${badges}</ul></section>

      <section class="card">
        <h2>How is CyberSafe working for you?</h2>
        <form id="fb-form">
          <label for="fb-rating">Rating</label>
          <select id="fb-rating"><option value="5">5 – Very helpful</option><option value="4">4 – Helpful</option><option value="3">3 – Okay</option><option value="2">2 – Confusing</option><option value="1">1 – Not helpful</option></select>
          <label for="fb-text">Comment (optional)</label>
          <textarea id="fb-text" maxlength="200" placeholder="What was useful? What was confusing? (Please don’t include personal details.)"></textarea>
          <p><button class="btn primary" type="submit">Send feedback</button> <span id="fb-msg" class="muted" role="status"></span></p>
        </form>
      </section>

      <section class="card">
        <h2>Your data</h2>
        <p class="muted">Progress lives only in this browser. Teachers can ask students to export it and compare results.</p>
        <div class="row"><button class="btn" data-action="exportData">Download my progress (JSON)</button><button class="btn danger" data-action="resetData">Reset all progress</button></div>
      </section>`;
  }

  /* -------------------------------- LEARN ------------------------------ */
  function renderLearn(id) {
    const m = D.modules.find(x => x.id === id);
    if (!m) {
      const cards = D.modules.map(x => `<a class="card module-card" href="#/learn/${x.id}"><span class="ico" aria-hidden="true">${x.icon}</span><h2>${esc(x.title)}</h2><p class="muted">${esc(x.blurb)}</p><p><span class="pill ${S.modules[x.id] ? 'done' : ''}">${S.modules[x.id] ? '✓ Completed' : x.minutes + ' min'}</span></p></a>`).join('');
      return `<h1>Learn</h1><p class="muted">Four short modules in plain language. Finish each one and tick it off.</p><div class="grid two">${cards}</div>`;
    }
    const lessons = m.lessons.map(l => `<article class="card lesson"><h2>${esc(l.h)}</h2>${l.p ? `<p>${esc(l.p)}</p>` : ''}${l.list ? `<ul>${l.list.map(i => `<li>${esc(i)}</li>`).join('')}</ul>` : ''}${l.tip ? `<p class="tip">💡 ${esc(l.tip)}</p>` : ''}</article>`).join('');
    const idx = D.modules.indexOf(m), nxt = D.modules[idx + 1];
    const done = !!S.modules[m.id];
    return `
      <p><a href="#/learn">← All modules</a></p>
      <h1><span aria-hidden="true">${m.icon}</span> ${esc(m.title)}</h1>
      <p class="muted">${esc(m.blurb)}</p>
      ${lessons}
      <section class="card"><h2>Try this today</h2>${m.checklist.map(c => `<label class="check"><input type="checkbox"> <span>${esc(c)}</span></label>`).join('')}</section>
      <div class="row">
        <button class="btn ${done ? '' : 'primary'}" data-action="complete" data-id="${m.id}">${done ? '✓ Completed (tap to undo)' : 'Mark module complete'}</button>
        ${nxt ? `<a class="btn" href="#/learn/${nxt.id}">Next: ${esc(nxt.title)} →</a>` : `<a class="btn" href="#/quiz">Take the quiz →</a>`}
      </div>`;
  }

  /* ------------------------------- PRACTICE ---------------------------- */
  function renderPractice(sub) {
    sub = ['phish', 'password', 'plan'].indexOf(sub) >= 0 ? sub : 'phish';
    const tabs = [['phish', '🎣 Phishing Lab'], ['password', '🔑 Password Coach'], ['plan', '🗺️ Safety Plan']]
      .map(([k, l]) => `<a href="#/practice/${k}" ${k === sub ? 'aria-current="page"' : ''}>${l}</a>`).join('');
    const body = sub === 'phish' ? renderPhish() : sub === 'password' ? renderPassword() : renderPlan();
    return `<h1>Practice</h1><nav class="subtabs" aria-label="Practice sections">${tabs}</nav>${body}`;
  }

  /* --- Phishing Lab --- */
  let ps = null;
  const curScenario = () => D.scenarios.find(s => s.id === ps.order[ps.i]);

  function scenarioHTML(sc) {
    const ctx = `<p class="context">📍 ${esc(sc.context)}</p>`;
    if (sc.kind === 'email') {
      return ctx + `<div class="mail"><dl class="mail-head">
        <div><dt>From</dt><dd>${esc(sc.from)}</dd></div><div><dt>To</dt><dd>you@student.example</dd></div>
        <div><dt>Subject</dt><dd><strong>${esc(sc.subject)}</strong></dd></div></dl>
        <div class="mail-body">${sc.body.map(p => `<p>${esc(p)}</p>`).join('')}
        ${sc.link ? `<p><button type="button" class="fake-link" data-action="reveal">${esc(sc.link.text)}</button></p>
          <p class="hint">Tip: tap the blue link to preview where it really goes. Nothing will open.</p>
          <p id="reveal-box" class="reveal" hidden><strong>Real destination:</strong> <code>${esc(sc.link.href)}</code></p>` : ''}
        </div></div>`;
    }
    if (sc.kind === 'chat') {
      return ctx + `<div class="chat"><p class="chat-from">💬 ${esc(sc.sender)}</p>${sc.messages.map(m => `<p class="bubble">${esc(m)}</p>`).join('')}</div>`;
    }
    return ctx + `<div class="browser"><div class="urlbar"><span aria-hidden="true">🔒</span> ${esc(sc.url)}</div>
      <div class="page"><h3>${esc(sc.pageTitle)}</h3>
      ${sc.fields.map(f => `<label>${esc(f)}<input type="text" disabled placeholder="(demo only: not typeable)"></label>`).join('')}
      <button class="btn primary" type="button" disabled>${esc(sc.button)}</button></div></div>`;
  }

  function renderPhish() {
    if (!ps) {
      const a = S.phish.attempts;
      return `<section class="card"><h2>🎣 Phishing Lab</h2>
        <p>You’ll see ${D.scenarios.length} realistic but <strong>fictional</strong> messages and websites. Some are scams, and some are perfectly safe. Decide which is which, then learn why.</p>
        <p class="muted">${a ? `So far: ${S.phish.correct} of ${a} correct (${pct(S.phish.correct, a)}%).` : 'Nothing you do here is sent anywhere.'}</p>
        <button class="btn primary" data-action="phishStart">Start scenarios</button></section>`;
    }
    if (ps.i >= ps.order.length) {
      const total = ps.order.length, p = pct(ps.correct, total);
      const msg = p >= 80 ? 'Excellent eye! You’re spotting the tricks.' : p >= 50 ? 'Good start. Review the red flags below and try again.' : 'Don’t worry. This is how everyone learns. Replay and watch for the red flags.';
      return `<section class="card"><h2>Round complete</h2><p class="big-num">${ps.correct}/${total} (${p}%)</p>${bar(p)}<p>${msg}</p>
        ${ps.missed.length ? `<h3>Review these</h3><ul>${ps.missed.map(id => `<li>${esc(D.scenarios.find(s => s.id === id).verdict)}</li>`).join('')}</ul>` : '<p>You got every one right 🎉</p>'}
        <div class="row"><button class="btn primary" data-action="phishStart">Play again</button><a class="btn" href="#/quiz">Take a quiz</a></div></section>`;
    }
    const sc = curScenario(), ans = ps.answered, last = ps.i === ps.order.length - 1;
    const fb = ans ? `<div id="fb" class="feedback ${ans.ok ? 'good' : 'bad'}" tabindex="-1">
        <h3>${ans.ok ? '✅ Correct!' : '❌ Not quite.'} This was ${sc.phish ? 'a scam / phishing attempt' : 'legitimate'}.</h3>
        <p>${esc(sc.verdict)}</p>
        <h4>${sc.phish ? 'Red flags to notice' : 'Why it’s safe'}</h4>
        <ul>${sc.flags.map(f => `<li><strong>${esc(f.t)}:</strong> ${esc(f.why)}</li>`).join('')}</ul>
        <p class="tip">💡 ${esc(sc.tip)}</p>
        <button class="btn primary" data-action="nextScenario">${last ? 'See results' : 'Next scenario →'}</button></div>` : '';
    return `<section class="card"><p class="kicker">Scenario ${ps.i + 1} of ${ps.order.length}</p>${bar(pct(ps.i, ps.order.length))}
      ${scenarioHTML(sc)}
      <div class="answer-row"><button class="btn danger" data-action="answer" data-v="phish" ${ans ? 'disabled' : ''}>🚩 Suspicious</button><button class="btn" data-action="answer" data-v="safe" ${ans ? 'disabled' : ''}>✅ Looks safe</button></div>
      ${fb}</section>`;
  }

  /* --- Password Coach --- */
  function renderPassword() {
    return `
      <section class="card">
        <h2>🔑 Password Coach</h2>
        <div class="callout warn"><strong>Practice only.</strong> Never type a password you really use. Everything here runs inside your browser and nothing is sent or saved, but good habits start now: try made-up passwords.</div>
        <label for="pw">Try a practice password</label>
        <div class="pw-row"><input id="pw" type="password" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" placeholder="Type a made-up password"><button type="button" class="btn" data-action="togglePw" aria-pressed="false">Show</button></div>
        <div id="pw-result" aria-live="polite"></div>
      </section>
      <section class="card">
        <h2>Generator</h2>
        <p class="muted">See what strong looks like. These are random and for practice. For real accounts, let your password manager generate and store them.</p>
        <label for="len">Random password length: <output id="len-out">16</output></label>
        <input id="len" type="range" min="12" max="32" value="16">
        <div class="row"><button class="btn primary" data-action="genPw">Random password</button><button class="btn" data-action="genPass">Passphrase</button></div>
        <div id="gen" aria-live="polite"></div>
      </section>
      <section class="card"><h2>Remember</h2><ul><li>Long and random beats short and “complicated”.</li><li>One unique password per account.</li><li>Add 2-step verification to your email first.</li><li>Never share a password or OTP with anyone.</li></ul></section>`;
  }

  function hasSequence(s) {
    const runs = ['0123456789', 'abcdefghijklmnopqrstuvwxyz', 'qwertyuiop', 'asdfghjkl', 'zxcvbnm'];
    for (const r of runs) {
      const rev = r.split('').reverse().join('');
      for (let i = 0; i <= r.length - 4; i++) if (s.indexOf(r.slice(i, i + 4)) >= 0 || s.indexOf(rev.slice(i, i + 4)) >= 0) return true;
    }
    return false;
  }

  function crackTime(bits) {
    const sec = Math.pow(2, bits) / 2 / 1e10;     // assumes 10 billion guesses/second (offline attack)
    if (sec < 1) return 'less than a second';
    let v = sec;
    for (const [n, k] of [['second', 60], ['minute', 60], ['hour', 24], ['day', 365]]) {
      if (v < k) { const r = Math.max(1, Math.round(v)); return r + ' ' + n + (r === 1 ? '' : 's'); }
      v /= k;
    }
    if (v < 1000) { const r = Math.round(v); return r + ' year' + (r === 1 ? '' : 's'); }
    if (v < 1e6) return 'thousands of years';
    if (v < 1e9) return 'millions of years';
    return 'billions of years or more';
  }

  function evaluate(pw) {
    const lowered = pw.toLowerCase();
    const leet = { '@': 'a', '4': 'a', '3': 'e', '1': 'i', '!': 'i', '0': 'o', '$': 's', '5': 's', '7': 't' };
    const norm = lowered.split('').map(c => leet[c] || c).join('');
    const has = { lower: /[a-z]/.test(pw), upper: /[A-Z]/.test(pw), digit: /\d/.test(pw), symbol: /[^A-Za-z0-9]/.test(pw) };
    const pool = (has.lower ? 26 : 0) + (has.upper ? 26 : 0) + (has.digit ? 10 : 0) + (has.symbol ? 33 : 0);
    let bits = pw.length * Math.log2(pool || 1);
    let penalty = 0;
    const issues = [];
    const exact = D.commonPasswords.indexOf(lowered) >= 0 || D.commonPasswords.indexOf(norm) >= 0;
    const containsCommon = !exact && D.commonPasswords.some(w => w.length >= 6 && /^[a-z]+$/.test(w) && norm.indexOf(w) >= 0);
    if (exact) issues.push('This is one of the most common passwords. Attackers try it first.');
    else if (containsCommon) { penalty += 30; issues.push('It contains a very common word, even with swaps like @ for “a”. Attackers try these swaps automatically.'); }
    if (/(.)\1{2,}/.test(pw)) { penalty += 10; issues.push('It repeats the same character 3+ times.'); }
    if (hasSequence(lowered)) { penalty += 10; issues.push('It has an easy sequence (like 1234, abcd or qwerty).'); }
    if (/(19|20)\d{2}/.test(pw)) { penalty += 8; issues.push('Years (like a birth year) are easy to guess.'); }
    if (/^[A-Za-z]+[\d!@#$%^&*]{1,4}$/.test(pw)) { penalty += 6; issues.push('“Word + a few digits/symbols” is a very predictable pattern.'); }
    // Passphrase: 3+ words joined by - _ or space. Estimate by words (11 bits each) instead of characters.
    const parts = pw.split(/[-_ ]+/).filter(Boolean);
    if (parts.length >= 3 && parts.every(p => /^[A-Za-z]{3,}\d{0,3}$/.test(p))) bits = Math.min(bits, parts.length * 11 + (has.digit ? 6 : 0));
    bits = Math.max(0, bits - penalty);
    if (exact) bits = Math.min(bits, 6);
    // A common word plus only a few extra characters (e.g. "P@ssw0rd1") is nearly as guessable as the word itself.
    if (containsCommon && pw.length <= 12) bits = Math.min(bits, 16);
    const score = bits < 28 ? 0 : bits < 40 ? 1 : bits < 50 ? 2 : bits < 70 ? 3 : 4;
    const kinds = [has.lower, has.upper, has.digit, has.symbol].filter(Boolean).length;
    return {
      score, label: ['Very weak', 'Weak', 'Fair', 'Strong', 'Excellent'][score], time: crackTime(bits), issues,
      checks: [
        [pw.length >= 12, 'At least 12 characters (14+ is better)'],
        [kinds >= 3 || pw.length >= 16, 'Mixes character types, or is a long (16+) passphrase'],
        [issues.length === 0, 'No common words, sequences or predictable patterns']
      ]
    };
  }

  function updatePw() {
    const box = $('#pw-result'), input = $('#pw');
    if (!box || !input) return;
    const pw = input.value;
    if (!pw) { box.innerHTML = '<p class="muted">Type a practice password to see feedback. It is checked on your device only.</p>'; return; }
    S.flags.pw = true;                      // remember only that the tool was used, never the text
    const r = evaluate(pw);
    box.innerHTML = `<div class="meter m${r.score}" role="img" aria-label="Strength: ${r.label}"><span></span><span></span><span></span><span></span><span></span></div>
      <p><strong>${r.label}</strong>. Estimated time to crack: <strong>${r.time}</strong></p>
      <ul class="checks">${r.checks.map(c => `<li><span class="${c[0] ? 'ok' : 'no'}">${c[0] ? '✓' : '✗'}</span> ${c[1]}</li>`).join('')}
      <li><span class="muted">•</span> Unique? Only you can check: never reuse it on another account.</li></ul>
      ${r.issues.length ? `<div class="callout warn"><strong>Watch out:</strong><ul>${r.issues.map(i => `<li>${i}</li>`).join('')}</ul></div>` : ''}
      <p class="hint">A rough estimate that assumes 10 billion guesses per second. Real-world safety also depends on how a site stores passwords, so use 2-step verification too.</p>`;
  }

  const CHARSET = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%&*?-_';
  function randInt(max) {                       // unbiased random integer using the browser's secure RNG
    const a = new Uint32Array(1), lim = Math.floor(4294967296 / max) * max;
    do { crypto.getRandomValues(a); } while (a[0] >= lim);
    return a[0] % max;
  }
  function showGen(text, note) {
    S.flags.pw = true;
    $('#gen').innerHTML = `<div class="gen-out"><code id="gen-text">${esc(text)}</code><button class="btn" data-action="copy">Copy</button></div><p class="muted">${esc(note)}</p>`;
  }

  /* --- Safety Plan --- */
  function planActions() {
    const ids = [];
    S.plan.concerns.forEach(cid => { const c = D.concerns.find(x => x.id === cid); if (c) c.actions.forEach(a => { if (ids.indexOf(a) < 0) ids.push(a); }); });
    return ids.map(id => Object.assign({ id }, D.actions[id])).sort((a, b) => a.p - b.p);
  }
  function planProgressHTML() {
    const acts = planActions(), done = acts.filter(a => S.plan.done[a.id]).length;
    return `<p><strong>${done} of ${acts.length}</strong> actions done</p>${bar(pct(done, acts.length))}`;
  }
  function renderPlan() {
    const sel = S.plan.concerns;
    const form = D.concerns.map(c => `<label class="check"><input type="checkbox" name="concern" value="${c.id}" ${sel.indexOf(c.id) >= 0 ? 'checked' : ''}> <span>${esc(c.label)}</span></label>`).join('');
    let plan = '';
    if (sel.length) {
      const groups = [[1, '🔥 Do today'], [2, '📅 This week'], [3, '🗓️ This month']];
      const acts = planActions();
      plan = `<section class="card" id="plan-out"><h2>Your Safety Plan</h2><div id="plan-progress">${planProgressHTML()}</div>
        ${groups.map(([p, title]) => { const list = acts.filter(a => a.p === p); return list.length ? `<div class="plan-group"><h3>${title}</h3>${list.map(a => `<div class="plan-item"><label class="check"><input type="checkbox" data-action="planTick" data-id="${a.id}" ${S.plan.done[a.id] ? 'checked' : ''}> <span>${esc(a.t)}<small>⏱ ${esc(a.time)}</small></span></label></div>`).join('')}</div>` : ''; }).join('')}
        </section>`;
    }
    return `<section class="card"><h2>🗺️ Safety Plan</h2><p>Tick what sounds like you. We’ll build a short, prioritised to-do list.</p>
      <fieldset style="border:0;padding:0;margin:0"><legend class="sr-only">Your concerns</legend>${form}</fieldset>
      <p><button class="btn primary" data-action="buildPlan">Build my plan</button> <span id="plan-msg" class="muted" role="status"></span></p></section>${plan}`;
  }

  /* -------------------------------- QUIZ ------------------------------- */
  let qz = null;
  function renderQuiz() {
    if (!qz) return quizSetup();
    return qz.done ? quizResults() : quizQuestion();
  }
  function quizSetup() {
    const hist = S.quizzes.slice(-5).reverse().map(q => `<li>${fmtDate(q.d)}: ${esc(q.cat === 'all' ? 'All topics' : CAT[q.cat])}, <strong>${q.score}/${q.total}</strong> (${pct(q.score, q.total)}%)</li>`).join('');
    return `<h1>Quiz</h1>
      <section class="card"><p>Short multiple-choice questions with instant feedback. ${S.quizzes.length ? '' : '<strong>Your first quiz is your baseline</strong>, so we can show how much you improve.'}</p>
        <label for="q-cat">Topic</label>
        <select id="q-cat"><option value="all">All topics</option>${Object.keys(CAT).map(k => `<option value="${k}">${CAT[k]}</option>`).join('')}</select>
        <label for="q-n">Number of questions</label>
        <select id="q-n"><option value="5">5 (quick)</option><option value="10" selected>10</option></select>
        <p><button class="btn primary" data-action="quizStart">Start quiz</button></p></section>
      ${hist ? `<section class="card"><h2>Recent results</h2><ul>${hist}</ul></section>` : ''}`;
  }
  function buildQuiz(questions, cat, noSave) {
    qz = { cat, noSave: !!noSave, i: 0, picked: null, answers: [], done: false,
      list: questions.map(q => Object.assign({}, q, { opts: shuffle(q.options.map((t, i) => ({ t, c: i === q.answer }))) })) };
  }
  function quizQuestion() {
    const q = qz.list[qz.i], answered = qz.picked !== null, last = qz.i === qz.list.length - 1;
    const opts = q.opts.map((o, i) => {
      let cls = 'opt', mark = '';
      if (answered) { if (o.c) { cls += ' correct'; mark = '✓ Correct answer'; } else if (i === qz.picked) { cls += ' wrong'; mark = '✗ Your answer'; } }
      return `<button type="button" class="${cls}" data-action="pick" data-i="${i}" ${answered ? 'disabled' : ''}><span class="letter" aria-hidden="true">${'ABCD'[i]}</span><span>${esc(o.t)}${mark ? `<em class="mark">${mark}</em>` : ''}</span></button>`;
    }).join('');
    const ok = answered && q.opts[qz.picked].c;
    return `<h1>Quiz</h1><section class="card"><p class="kicker">Question ${qz.i + 1} of ${qz.list.length} · ${CAT[q.cat]}</p>${bar(pct(qz.i, qz.list.length))}
      <h2>${esc(q.q)}</h2><div class="opts">${opts}</div>
      ${answered ? `<div id="qfb" class="feedback ${ok ? 'good' : 'bad'}" tabindex="-1"><h3>${ok ? '✅ Correct!' : '❌ Not quite.'}</h3><p>${esc(q.explain)}</p><button class="btn primary" data-action="nextQ">${last ? 'See results' : 'Next question →'}</button></div>` : ''}</section>`;
  }
  function quizResults() {
    const r = qz.result, p = pct(r.score, r.total);
    const prev = !qz.noSave && S.quizzes.length > 1 ? S.quizzes[S.quizzes.length - 2] : null;
    const cmp = prev ? `<p>Previous quiz: ${pct(prev.score, prev.total)}% → this one: ${p}% (${p - pct(prev.score, prev.total) >= 0 ? '+' : ''}${p - pct(prev.score, prev.total)} points)</p>` : '';
    const msg = p >= 90 ? 'Outstanding! You’re a digital safety pro.' : p >= 70 ? 'Nice work. A little review will make it perfect.' : p >= 50 ? 'Good effort. Review the explanations below.' : 'A great start. Learning is the point. Review the modules and try again.';
    const missedQs = r.missed.map(id => qz.list.find(q => q.id === id)).filter(Boolean);
    const missedHTML = missedQs.map(q => {
      const mine = qz.answers.find(a => a.id === q.id), correct = q.opts.find(o => o.c);
      return `<div class="missed"><h3>${esc(q.q)}</h3><p>Your answer: <strong>${esc(q.opts[mine.pick].t)}</strong></p><p>Correct answer: <strong>${esc(correct.t)}</strong></p><p><strong>Why:</strong> ${esc(q.explain)}</p></div>`;
    }).join('');
    const cats = Array.from(new Set(missedQs.map(q => q.cat)));
    return `<h1>Quiz results</h1><section class="card"><p class="big-num">${r.score}/${r.total} (${p}%)</p>${bar(p)}<p>${msg}</p>${cmp}
      <div class="row"><button class="btn primary" data-action="quizReset">New quiz</button>${missedQs.length ? '<button class="btn" data-action="retryMissed">Retry missed questions</button>' : ''}</div></section>
      ${missedQs.length ? `<section class="card"><h2>What you got wrong, and why</h2>${missedHTML}<p><strong>Review:</strong> ${cats.map(c => `<a href="#/learn/${c}">${CAT[c]}</a>`).join(' · ')}</p></section>` : '<section class="card"><h2>Perfect score 🎉</h2><p>You got every question right.</p></section>'}`;
  }

  /* --------------------------------- SOS ------------------------------- */
  function renderSOS(id) {
    const E = D.emergency, g = E.guides.find(x => x.id === id);
    const help = `<section class="card"><h2>Who to contact</h2><ul>${E.help.map(h => `<li><strong>${esc(h.label)}:</strong> ${h.href ? `<a href="${h.href}" ${h.href.indexOf('http') === 0 ? 'target="_blank" rel="noopener noreferrer"' : ''}>${esc(h.text)}</a>` : esc(h.text)}</li>`).join('')}</ul><p class="hint">${esc(E.helpNote)}</p></section>`;
    if (!g) {
      return `<h1>Emergency help</h1>
        <div class="callout alert"><strong>Stay calm. Act fast. It’s not your fault.</strong> Scammers are professionals. Choose what happened and follow the steps.</div>
        <div class="grid two">${E.guides.map(x => `<a class="card sos-card" href="#/sos/${x.id}"><span class="ico" aria-hidden="true">${x.icon}</span><h2>${esc(x.title)}</h2><p class="muted">${esc(x.sub)}</p></a>`).join('')}</div>${help}`;
    }
    return `<p><a href="#/sos">← All emergencies</a></p><h1><span aria-hidden="true">${g.icon}</span> ${esc(g.title)}</h1>
      <div class="callout alert"><strong>Do these in order.</strong> Tick each step as you go.</div>
      <section class="card"><ol class="steps">${g.steps.map(s => `<li><label><input type="checkbox"><span>${esc(s)}</span></label></li>`).join('')}</ol></section>
      <section class="card"><h2>Please don’t</h2><ul>${g.dont.map(d => `<li>${esc(d)}</li>`).join('')}</ul></section>${help}`;
  }

  /* ------------------------------ ACTIONS ------------------------------ */
  const ACTIONS = {
    complete(el) { const id = el.dataset.id; if (S.modules[id]) delete S.modules[id]; else S.modules[id] = Date.now(); save(); render(); },

    phishStart() { ps = { order: shuffle(D.scenarios.map(s => s.id)), i: 0, correct: 0, answered: null, missed: [] }; render(); },
    reveal() { const b = $('#reveal-box'); if (b) b.hidden = !b.hidden; },
    answer(el) {
      if (!ps || ps.answered) return;
      const sc = curScenario(), ok = (el.dataset.v === 'phish') === sc.phish;
      ps.answered = { ok };
      if (ok) ps.correct++; else ps.missed.push(sc.id);
      S.phish.attempts++; if (ok) S.phish.correct++;
      save(); render('#fb');
    },
    nextScenario() {
      ps.i++; ps.answered = null;
      if (ps.i >= ps.order.length) { S.phish.sessions.push({ d: Date.now(), correct: ps.correct, total: ps.order.length }); save(); }
      render();
    },

    togglePw(el) { const i = $('#pw'), show = i.type === 'password'; i.type = show ? 'text' : 'password'; el.textContent = show ? 'Hide' : 'Show'; el.setAttribute('aria-pressed', String(show)); },
    genPw() {
      const len = +$('#len').value; let out = '';
      for (let i = 0; i < len; i++) out += CHARSET[randInt(CHARSET.length)];
      showGen(out, `${len} random characters ≈ ${Math.floor(len * Math.log2(CHARSET.length))} bits of randomness. Very strong, but hard to remember, so let a password manager remember it.`);
    },
    genPass() {
      const w = D.words, n = 6; let out = [];
      for (let i = 0; i < n; i++) out.push(w[randInt(w.length)]);
      const num = 10 + randInt(90);
      const bits = Math.floor(n * Math.log2(w.length) + Math.log2(90));
      showGen(out.join('-') + '-' + num, `≈ ${bits} bits with this small demo word list of ${w.length} words. Real generators use lists of 7,776+ words, so add more words for important accounts.`);
    },
    copy(el) {
      const t = $('#gen-text'); if (!t || !navigator.clipboard) { el.textContent = 'Select & copy manually'; return; }
      navigator.clipboard.writeText(t.textContent).then(() => { el.textContent = 'Copied ✓'; }, () => { el.textContent = 'Copy failed'; });
    },

    buildPlan() {
      const picked = Array.from(document.querySelectorAll('input[name=concern]:checked')).map(i => i.value);
      if (!picked.length) { $('#plan-msg').textContent = 'Pick at least one concern first.'; return; }
      S.plan.concerns = picked; save(); render('#plan-out h2');
    },

    quizStart() {
      const cat = $('#q-cat').value, n = +$('#q-n').value;
      const pool = D.questions.filter(q => cat === 'all' || q.cat === cat);
      buildQuiz(shuffle(pool).slice(0, n), cat); render();
    },
    pick(el) {
      if (!qz || qz.picked !== null) return;
      const i = +el.dataset.i, q = qz.list[qz.i];
      qz.picked = i; qz.answers.push({ id: q.id, ok: q.opts[i].c, pick: i }); render('#qfb');
    },
    nextQ() {
      if (qz.i < qz.list.length - 1) { qz.i++; qz.picked = null; render(); return; }
      const score = qz.answers.filter(a => a.ok).length, missed = qz.answers.filter(a => !a.ok).map(a => a.id);
      qz.result = { score, total: qz.list.length, missed }; qz.done = true;
      if (!qz.noSave) { S.quizzes.push({ d: Date.now(), cat: qz.cat, score, total: qz.list.length, missed }); save(); }
      render();
    },
    quizReset() { qz = null; render(); },
    retryMissed() {
      const ids = qz.result.missed, qs = D.questions.filter(q => ids.indexOf(q.id) >= 0);
      buildQuiz(shuffle(qs), qz.cat, true); render();
    },

    exportData() {
      const blob = new Blob([JSON.stringify(Object.assign({ app: 'CyberSafe prototype', exportedAt: new Date().toISOString() }, S), null, 2)], { type: 'application/json' });
      const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'cybersafe-progress.json';
      document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 1000);
    },
    resetData() {
      if (!confirm('Reset all CyberSafe progress on this device? This cannot be undone.')) return;
      S = blank(); save(); ps = null; qz = null; render();
    }
  };

  app.addEventListener('click', e => {
    const el = e.target.closest('[data-action]');
    if (!el || el.tagName === 'INPUT') return;
    const fn = ACTIONS[el.dataset.action]; if (fn) fn(el, e);
  });
  app.addEventListener('change', e => {
    const el = e.target;
    if (el.dataset && el.dataset.action === 'planTick') {
      if (el.checked) S.plan.done[el.dataset.id] = true; else delete S.plan.done[el.dataset.id];
      save(); const p = $('#plan-progress'); if (p) p.innerHTML = planProgressHTML();
    }
  });
  app.addEventListener('input', e => {
    if (e.target.id === 'pw') updatePw();
    if (e.target.id === 'len') $('#len-out').textContent = e.target.value;
  });
  app.addEventListener('submit', e => {
    if (e.target.id !== 'fb-form') return;
    e.preventDefault();
    S.feedback.push({ d: Date.now(), rating: +$('#fb-rating').value, text: $('#fb-text').value.slice(0, 200) });
    save(); render('#fb-msg');
    const m = $('#fb-msg'); if (m) { m.textContent = 'Thank you! Saved on this device.'; m.focus(); }
  });

  route();
})();
